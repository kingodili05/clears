<?php


$ovnimail = "";

    $ovnitoken = "7432500018:AAHkby-7D7wEhs1uMaW4r1wPLOuHvC48oy0";
    $ovnichat = "5850651454";


 ?>